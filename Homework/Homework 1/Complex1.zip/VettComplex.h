
//#include "Complex.h"
#include "scambia.h"

const int DIM=10;
typedef Complesso Vettore[DIM];

// Prototipi di funzioni
void LeggiElementi(Vettore,int &);
void StampaVettore(const Vettore, const int);
void ModuloBubbleSort(Vettore, const int);  

