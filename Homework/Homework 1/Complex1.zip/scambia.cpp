#include "scambia.h"

void scambia(T & x, T & y) {
	T temp;
	temp=x;
	x=y;
	y=temp;
}


void scambia(T * ptrx, T * ptry) {
	T temp;
	temp=*ptrx;
	*ptrx=*ptry;
	*ptry=temp;
}
