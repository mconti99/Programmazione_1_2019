#include "Complex.h"
typedef Complesso T;

void scambia(T &, T &);
void scambia (T *, T *);
